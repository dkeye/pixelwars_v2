﻿# pixelwars_v2

### Requirements

* ASP.NET Core SDK 6
* ASP.NET Core Runtime 6
* .NET Runtime 6

[Windows](https://learn.microsoft.com/ru-ru/dotnet/core/install/windows)
[Linux](https://learn.microsoft.com/ru-ru/dotnet/core/install/linux/)

### Installation and run

```bash 
git clone git@github.com:dkeye/pixelwars_v2.git

dotnet restore
dotnet run
```
