﻿using BackendWebAPI.Models;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Driver;
using System.Drawing;
using static System.Net.Mime.MediaTypeNames;

namespace BackendWebAPI.Services
{
    public class PixelWarsService
    {
        private readonly IMongoCollection<PixelWarsCollection> _PixelWarsCollectionName;

        public PixelWarsService(
            IOptions<PixelWarsDatabaseSettings> pixelwarsdatabasesettings)
        {
            var mongoClient = new MongoClient(
                pixelwarsdatabasesettings.Value.ConnectionString);

            var mongoDatabase = mongoClient.GetDatabase(
                pixelwarsdatabasesettings.Value.DatabaseName);

            _PixelWarsCollectionName = mongoDatabase.GetCollection<PixelWarsCollection>(
                pixelwarsdatabasesettings.Value.PixelWarsCollectionName);
        }

        public async Task<List<PixelWarsCollection>> GetAsync() =>
                await _PixelWarsCollectionName.Find(_ => true).ToListAsync();

        public async Task<PixelWarsCollection?> GetByIdAsync(string id) =>
            await _PixelWarsCollectionName.Find(x => x.Id == id).FirstOrDefaultAsync();

        public async Task<PixelWarsCollection?> GetByNameAsync(string name) =>
            await _PixelWarsCollectionName.Find(x => x.Name == name).FirstOrDefaultAsync();

        public async Task CreateAsync(PixelWarsCollection newObject) =>
            await _PixelWarsCollectionName.InsertOneAsync(newObject);

        public async Task<UpdateResult> AddSuareByName(string name, int x, int y, string color)
        {
            var filter = await _PixelWarsCollectionName.Find(x => x.Name == name).FirstOrDefaultAsync();

            return await _PixelWarsCollectionName.UpdateOneAsync(filter, new BsonDocument("$addToSet", new BsonDocument("Squares", new BsonArray { new BsonDocument("x", x), new BsonDocument("y", y), new BsonDocument("color", color) }))));
        }
            
    }
}
